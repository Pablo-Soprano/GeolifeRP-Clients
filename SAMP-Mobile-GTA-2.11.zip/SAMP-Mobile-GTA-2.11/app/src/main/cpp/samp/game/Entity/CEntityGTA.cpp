#include "CEntityGTA.h"
#include "game/game.h"
#include "game/Collision/ColStore.h"
#include "patch.h"
#include "game/General.h"
#include "game/Models/BaseModelInfo.h"
#include "game/Models/ModelInfo.h"
#include "game/References.h"
#include "game/Pools.h"

extern CGame* pGame;

CEntityGTA::CEntityGTA() : CPlaceable() {
    m_nStatus = STATUS_ABANDONED;
    m_nType = ENTITY_TYPE_NOTHING;

    m_nFlags = 0;
    m_bIsVisible = true;
    m_bBackfaceCulled = true;

    m_nScanCode = 0;
    m_nAreaCode = eAreaCodes::AREA_CODE_NORMAL_WORLD;
    m_nModelIndex = 0xFFFF;
    m_pRwObject = nullptr;
    m_nIplIndex = 0;
    m_nRandomSeed = CGeneral::GetRandomNumber();
    m_pReferences = nullptr;
    m_pStreamingLink = nullptr;
    m_nNumLodChildren = 0;
    m_nNumLodChildrenRendered = 0;
    m_pLod = nullptr;
}

CEntityGTA::~CEntityGTA()
{
    if (m_pLod)
        m_pLod->m_nNumLodChildren--;

    CEntityGTA::DeleteRwObject();
    CEntityGTA::ResolveReferences();
}

void CEntityGTA::ResolveReferences()
{
    auto refs = m_pReferences;
    while (refs) {
        if (*refs->m_ppEntity == this)
            *refs->m_ppEntity = nullptr;

        refs = refs->m_pNext;
    }

    refs = m_pReferences;
    if (!refs)
        return;

    refs->m_ppEntity = nullptr;
    while (refs->m_pNext)
        refs = refs->m_pNext;

    refs->m_pNext = CReferences::pEmptyList;
    CReferences::pEmptyList = m_pReferences;
    m_pReferences = nullptr;
}

void CEntityGTA::Add()
{
    CHook::CallFunction<void>(g_libGTASA + 0x48DCE0, this);
}

void CEntityGTA::SetInterior(int interiorId, bool needRefresh)
{
    m_nAreaCode = static_cast<eAreaCodes>(interiorId);

    if ( this == (CEntityGTA*)pGame->FindPlayerPed()->m_pPed )
    {
        CGame::currArea = interiorId;

        auto pos = GetPosition();
        CColStore::RequestCollision(&pos, m_nAreaCode);

        if(interiorId == 0) {
            CHook::CallFunction<void>(g_libGTASA + 0x4C4600, false);
        }

    }

}

float CEntityGTA::GetDistanceFromLocalPlayerPed() const
{
    auto pLocalPlayerPed = pGame->FindPlayerPed();

    return DistanceBetweenPoints(GetPosition(), pLocalPlayerPed->m_pPed->GetPosition());
}

float CEntityGTA::GetDistanceFromCamera()
{
    if(!this)
        return 0;

    CCamera& TheCamera = *reinterpret_cast<CCamera*>(g_libGTASA + 0x9F86F8);
    return DistanceBetweenPoints(GetPosition(), TheCamera.GetPosition());
}

float CEntityGTA::GetDistanceFromPoint(float X, float Y, float Z) const
{
    CVector vec(X, Y, Z);

    return DistanceBetweenPoints(GetPosition(), vec);
}

void CEntityGTA::SetCollisionChecking(bool bCheck)
{
    m_bCollisionProcessed = bCheck;
}

void CEntityGTA::UpdateRpHAnim() {
    if (const auto atomic = GetFirstAtomic(m_pRwClump)) {
        if (RpSkinGeometryGetSkin(RpAtomicGetGeometry(atomic)) && !m_bDontUpdateHierarchy) {
            RpHAnimHierarchyUpdateMatrices(GetAnimHierarchyFromSkinClump(m_pRwClump));
        }
    }
}

void CEntityGTA::UpdateRwFrame()
{
    if (!m_pRwObject)
        return;

    RwFrameUpdateObjects(static_cast<RwFrame*>(rwObjectGetParent(m_pRwObject)));
}

void CEntityGTA::DeleteRwObject()
{
    if(!*(uintptr*)this) return;

    (( void (*)(CEntityGTA*))(*(void**)(*(uintptr*)this + (VER_x32 ? 0x24 : 0x24*2))))(this);
}

void CEntityGTA::UpdateRW() {
    if (!this || !m_pRwObject) return;

    auto parentMatrix = GetModellingMatrix();
    if (!parentMatrix) return;

    if (m_matrix)
        m_matrix->UpdateRwMatrix(parentMatrix);
    else
        m_placement.UpdateRwMatrix(parentMatrix);
}

RwMatrix* CEntityGTA::GetModellingMatrix() {
    if (!m_pRwObject)
        return nullptr;

    return RwFrameGetMatrix(RwFrameGetParent(m_pRwObject));
}

CBaseModelInfo* CEntityGTA::GetModelInfo() const {
    return CModelInfo::GetModelInfo(m_nModelIndex);
}

void CEntityGTA::Add(const CRect* rect) {
    CHook::CallFunction<void>(g_libGTASA + 0x48DD4C, this, rect);
}

void CEntityGTA::Remove() {
    CHook::CallFunction<void>(g_libGTASA + 0x48E024, this);
}

void CEntityGTA::SetModelIndex(uint32_t index) {
}

void CEntityGTA::SetModelIndexNoCreate(uint32_t index) {
}

void CEntityGTA::SetIsStatic(bool isStatic) {
}

CRect CEntityGTA::GetBoundRect()
{
    CRect rect;
    if (!this || !m_pRwObject) {
        rect.left = 0.0f;
        rect.right = 0.0f;
        rect.top = 0.0f;
        rect.bottom = 0.0f;
        return rect;
    }
    return CHook::CallFunction<CRect>(g_libGTASA + 0x48DD00, this);
}

CVector CEntityGTA::GetBoundCentre()
{
    if (!this || !m_pRwObject) {
        return CVector(0.0f, 0.0f, 0.0f);
    }
    return CHook::CallFunction<CVector>(g_libGTASA + 0x48DD30, this);
}

float CEntityGTA::GetBoundRadius()
{
    if (!this || !m_pRwObject) {
        return 1.0f;
    }
    return CHook::CallFunction<float>(g_libGTASA + 0x48DD60, this);
}

void CEntityGTA::RegisterReference(CEntityGTA** entity)
{
    if (IsBuilding() && !m_bIsTempBuilding && !m_bIsProcObject && !m_nIplIndex)
        return;

    auto refs = m_pReferences;
    while (refs) {
        if (refs->m_ppEntity == entity) {
            return;
        }
        refs = refs->m_pNext;
    }

    if (!m_pReferences && !CReferences::pEmptyList) {
        auto iPedsSize = GetPedPoolGta()->GetSize();
        for (int32 i = 0; i < iPedsSize; ++i) {
            auto ped = GetPedPoolGta()->GetAt(i);
            if (ped) {
                ped->PruneReferences();
                if (CReferences::pEmptyList)
                    break;
            }

        }

        if (!CReferences::pEmptyList) {
            auto iVehsSize = GetVehiclePoolGta()->GetSize();
            for (int32 i = 0; i < iVehsSize; ++i) {
                auto vehicle = GetVehiclePoolGta()->GetAt(i);
                if (vehicle) {
                    vehicle->PruneReferences();
                    if (CReferences::pEmptyList)
                        break;
                }

            }
        }

        if (!CReferences::pEmptyList) {
            auto iObjectsSize = GetObjectPoolGta()->GetSize();
            for (int32 i = 0; i < iObjectsSize; ++i) {
                auto obj = GetObjectPoolGta()->GetAt(i);
                if (obj) {
                    obj->PruneReferences();
                    if (CReferences::pEmptyList)
                        break;
                }
            }
        }
    }

    if (CReferences::pEmptyList) {
        auto pEmptyRef = CReferences::pEmptyList;
        CReferences::pEmptyList = pEmptyRef->m_pNext;
        pEmptyRef->m_pNext = m_pReferences;
        m_pReferences = pEmptyRef;
        pEmptyRef->m_ppEntity = entity;
    }
}

void CEntityGTA::PruneReferences()
{
    if (!m_pReferences)
        return;

    auto refs = m_pReferences;
    auto ppPrev = &m_pReferences;
    while (refs) {
        if (*refs->m_ppEntity == this) {
            ppPrev = &refs->m_pNext;
            refs = refs->m_pNext;
        }
        else {
            auto refTemp = refs->m_pNext;
            *ppPrev = refs->m_pNext;
            refs->m_pNext = CReferences::pEmptyList;
            CReferences::pEmptyList = refs;
            refs->m_ppEntity = nullptr;
            refs = refTemp;
        }
    }
}

void CEntityGTA::CleanUpOldReference(CEntityGTA** entity)
{
    if (!m_pReferences)
        return;

    auto refs = m_pReferences;
    auto ppPrev = &m_pReferences;
    while (refs->m_ppEntity != entity) {
        ppPrev = &refs->m_pNext;
        refs = refs->m_pNext;
        if (!refs)
            return;
    }

    *ppPrev = refs->m_pNext;
    refs->m_pNext = CReferences::pEmptyList;
    refs->m_ppEntity = nullptr;
    CReferences::pEmptyList = refs;
}